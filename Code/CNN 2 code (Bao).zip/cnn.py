# -*- coding: utf-8 -*-


# Import keras libraries and packages
import keras
from keras.models import Sequential
from keras.layers import Convolution2D, MaxPooling2D, Flatten, Dense, Dropout
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import ModelCheckpoint
import numpy as np
from keras.preprocessing import image

# Initializing the CNN
classifier = Sequential()

# Convolution
classifier.add(Convolution2D(filters=64, kernel_size=3, input_shape=(64, 64, 3), activation='relu'))

# Pooling
classifier.add(MaxPooling2D(pool_size=(2, 2)))

# Convolution
classifier.add(Convolution2D(filters=32, kernel_size=3, activation='relu'))

# Pooling
classifier.add(MaxPooling2D(pool_size=(2, 2)))

# Flattening
classifier.add(Flatten())

# Full connected layer
classifier.add(Dense(units=128, activation='relu'))
classifier.add(Dropout(0.5))
classifier.add(Dense(units=4, activation='softmax'))

# Compiling
classifier.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])

# Start training
# Image preprocessing

train_datagen = ImageDataGenerator(
    rescale=1. / 255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    vertical_flip=True
    )

test_datagen = ImageDataGenerator(rescale=1. / 255)

training_set = train_datagen.flow_from_directory(
    'dataset/training_set',
    target_size=(64, 64),
    batch_size=32,
    class_mode='categorical')

test_set = test_datagen.flow_from_directory(
    'dataset/test_set',
    target_size=(64, 64),
    batch_size=32,
    class_mode='categorical')


# checkpoint
filepath="weights.best.hdf5"
checkpoint = ModelCheckpoint(filepath, monitor='val_acc', verbose=1, save_best_only=True, mode='max')
callbacks_list = [checkpoint]



# fit to model
history = classifier.fit_generator(
    training_set,
    steps_per_epoch=486,
    epochs=250,
    validation_data=test_set,
    validation_steps=120,
    callbacks=callbacks_list
    )



import matplotlib.pyplot as plt

print(history.history.keys())
# summarize history for accuracy
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()
# summarize history for loss
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

# reload the best weights
classifier.load_weights("weights.best.hdf5")
# Compiling
classifier.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])



# Making prediction

test_image = image.load_img('dataset/prediction_images/leopards-1.jpg', target_size=(64, 64))
plt.imshow(test_image)

test_image = image.img_to_array(test_image)
test_image = np.expand_dims(test_image, 0)

print("\n\n")
pred = classifier.predict(test_image)

if pred[0][0] == 1:
    print('Prediction: Bear')
elif pred[0][1] == 1:
    print('Prediction: Dog')
elif pred[0][2] == 1:
    print('Prediction: Gorilla')
elif pred[0][3] == 1:
    print('Prediction: Leopards')
    







